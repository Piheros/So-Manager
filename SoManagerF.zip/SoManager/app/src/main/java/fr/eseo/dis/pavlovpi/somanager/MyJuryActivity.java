package fr.eseo.dis.pavlovpi.somanager;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import fr.eseo.dis.pavlovpi.somanager.data.JuryItem;
import fr.eseo.dis.pavlovpi.somanager.data.adapters.JuryAdapter;
import fr.eseo.dis.pavlovpi.somanager.data.adapters.ProjectsAdapter;

public class MyJuryActivity extends AppCompatActivity {

    private static final String TAG = MyJuryActivity.class.getSimpleName();

    private FloatingActionButton buttonToProject;

    private String pageType = "MYJUR";
    private String url = "https://192.168.4.248/pfe/webservice.php?q=" + pageType +"&user=";

    private String userName;
    private String token;
    private String titleProject;

    private RecyclerView myRecyclerView;
    private JuryAdapter mJuryAdapter;
    private ArrayList<JuryItem> mJuryList;

    private RequestQueue mRequestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_so_manager);

        buttonToProject = findViewById(R.id.fab);

        callButtonListener();

        setUserNameandToken();
        createUrlToGetMyJurys();

        myRecyclerView = findViewById(R.id.JuryList);
        myRecyclerView.setHasFixedSize(true);
        myRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mJuryList = new ArrayList<>();

        mRequestQueue = Volley.newRequestQueue(this);

        getJSONMyJuries();
    }

    private void getJSONMyJuries() {
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, this.url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            Log.d(TAG, "JSON receive");
                            JSONArray responseArray = response.getJSONArray("juries");

                            for (int i = 0; i < responseArray.length(); i++) {
                                JSONObject hit = responseArray.getJSONObject(i);

                                String idJury = hit.getString("idJury");
                                String date = hit.getString("date");

                                JSONObject info = hit.getJSONObject("info");

                                JSONArray projectsArray = info.getJSONArray("projects");

                                for(int j = 0; j < projectsArray.length(); j++) {
                                    JSONObject projectsObject = projectsArray.getJSONObject(j);

                                    titleProject = projectsObject.getString("title");
                                    mJuryList.add(new JuryItem(idJury, date, titleProject));
                                }
                            }

                            mJuryAdapter = new JuryAdapter(MyJuryActivity.this, mJuryList);
                            myRecyclerView.setAdapter(mJuryAdapter);

                        } catch (JSONException e) {
                            Log.e(TAG,"JSON does not work");
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "SoManager does not work");
                error.printStackTrace();
            }
        });

        mRequestQueue.add(request);
    }

    private void setUserNameandToken(){
        Intent i = getIntent();
        this.userName = i.getStringExtra("user_name");
        this.token = i.getStringExtra("token");
        Log.d(TAG, "Le user name = " + this.userName);
        Log.d(TAG, "Le TOKEN = " + this.token);
    }

    private void createUrlToGetMyJurys(){
        this.url = this.url + this.userName + "&token=" + this.token;
        Log.d(TAG + " -- URL de MyJurys", "URL = " + this.url);
    }

    private void callButtonListener(){
        buttonToProject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(MyJuryActivity.this, ProjectsActivity.class);
                myIntent.putExtra("user_name",userName);
                myIntent.putExtra("token",token);
                startActivity(myIntent);
            }
        });
    }

    public void clickJuryCard(JuryItem currentItem) {
        Intent intent = new Intent(this, DetailsActivity.class);
        //intent.putExtra(JURY_EXTRA, (Parcelable) currentItem);
        intent.putExtra("user_name",userName);
        intent.putExtra("token",token);
        intent.putExtra("project_title", titleProject);
        startActivity(intent);
    }
}
