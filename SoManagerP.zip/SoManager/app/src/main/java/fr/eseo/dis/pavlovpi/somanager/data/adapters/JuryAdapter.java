package fr.eseo.dis.pavlovpi.somanager.data.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import fr.eseo.dis.pavlovpi.somanager.ConnectionActivity;
import fr.eseo.dis.pavlovpi.somanager.R;
import fr.eseo.dis.pavlovpi.somanager.data.JuryItem;

public class JuryAdapter extends RecyclerView.Adapter<JuryAdapter.JuryViewHolder> {

    private Context mContext;
    private ConnectionActivity activity;
    private List<Integer> expandedPositions;
    private ArrayList<JuryItem> mJuryList;

    public JuryAdapter(Context context, ArrayList<JuryItem> juryList){
        this.expandedPositions = new ArrayList<>();
        this.mContext = context;
        this.mJuryList = juryList;
    }

    @NonNull
    @Override
    public JuryAdapter.JuryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.jury_card_view, parent, false);
        CardView filmCardView = (CardView)v;
        filmCardView.setCardElevation(3 * ConnectionActivity.NEW_CARD_COUNTER++);
        return new JuryViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull JuryViewHolder holder, final int position) {
        final JuryItem currentItem = mJuryList.get(position);

        String idJury = currentItem.getIdJury();
        String dateJury = currentItem.getDate();
        String infoJury = currentItem.getInfo();

        holder.mTextViewIdJury.setText("Id_Jury = " + idJury);
        holder.mTextViewDateJury.setText("Date_Jury :" + dateJury);
        holder.mTextViewDInfoJury.setText("Info_Jury : " + infoJury);
    }

    @Override
    public int getItemCount() {
        return this.mJuryList.size();
    }

    class JuryViewHolder extends RecyclerView.ViewHolder{

        private final View view;

        public TextView mTextViewIdJury;
        public TextView mTextViewDateJury;
        public TextView mTextViewDInfoJury;

        public JuryViewHolder(View itemView) {
            super(itemView);
            this.view = itemView;
            mTextViewIdJury = itemView.findViewById(R.id.jury_id_view);
            mTextViewDateJury = itemView.findViewById(R.id.jury_date);
            mTextViewDInfoJury = itemView.findViewById(R.id.jury_info);
        }

    }

}
