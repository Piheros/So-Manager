package fr.eseo.dis.pavlovpi.somanager.data;

public class JuryItem {

    private String idJury;
    private String date;
    private String info;

    public JuryItem(String idJury, String date, String info){
        this.idJury = idJury;
        this.date = date;
        this.info = info;
    }

    public String getIdJury(){
        return this.idJury;
    }

    public String getDate(){
        return this.date;
    }

    public String getInfo(){
        return this.info;
    }

}
