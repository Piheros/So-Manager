package fr.eseo.dis.pavlovpi.somanager;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class HomeActivity extends AppCompatActivity {

    private Button btnVisitor;
    private Button btnTestConnection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btnVisitor = findViewById(R.id.button_visitor);
        btnTestConnection = findViewById(R.id.button_connection);

        btnVisitor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(HomeActivity.this, SoManagerActivity.class);
                startActivity(myIntent);
            }
        });

        btnTestConnection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(HomeActivity.this, ConnectionActivity.class);
                startActivity(myIntent);
            }
        });

        btnVisitor.setVisibility(View.VISIBLE);
        btnTestConnection.setVisibility(View.VISIBLE);
    }

}
