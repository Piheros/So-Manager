package fr.eseo.dis.pavlovpi.somanager;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import fr.eseo.dis.pavlovpi.somanager.data.ProjectItem;
import fr.eseo.dis.pavlovpi.somanager.data.adapters.ProjectsAdapter;

public class ConnectionActivity extends AppCompatActivity {

    Button btnGetRequest, btnPostRequest;

    EditText textUserName;
    EditText textPassword;

    private String userName;
    private String password;

    private String pageType = "LOGON";
    private String baseUrl = "https://192.168.4.248/pfe/webservice.php?q=" + pageType +"&user=";
    private String url;

    private String result;
    private String api;
    private String token;
    private RequestQueue mRequestQueue;

    private Context mContext;
    private Activity mActivity;
    private PopupWindow mPopupWindow;
    private LinearLayout mLinearLayout;

    public static final String JURY_EXTRA = "jury_extra";
    public static int NEW_CARD_COUNTER;
    private ProjectsAdapter projectsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_connection);

        // Recycler view card
        /*
        this.NEW_CARD_COUNTER = 0;
        RecyclerView recycler = findViewById(R.id.JuryList);
        recycler.setHasFixedSize(true);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        recycler.setLayoutManager(llm);
        // TODO projectsAdapter = new ProjectsAdapter(this);
        recycler.setAdapter(projectsAdapter);
        */
        // Volley
        NukeSSL.nuke();
        mRequestQueue = Volley.newRequestQueue(this);
        init();
    }

    private void init() {
        getViews();
        setListeners();
        //restClient = HTTPSRestClient.getInstance();
    }

    @SuppressLint("CutPasteId")
    private void getViews() {
        btnGetRequest = findViewById(R.id.connexion_button);
        btnPostRequest = findViewById(R.id.connexion_button);
        // textResponse = (TextView) findViewById(R.id.textResponse);

        textUserName = findViewById(R.id.user_name); // voir pour en faire une méthode après
        textPassword = findViewById(R.id.password);
    }

    private void setListeners() {
        mContext = getApplicationContext();
        mActivity = ConnectionActivity.this;
        mLinearLayout = findViewById(R.id.linearLayoutConnection);

        btnGetRequest.setOnClickListener(new View.OnClickListener() {
            //EditText textTest = findViewById(R.id.user_name);
            @Override
            public void onClick(View v) {

                userName = "chavijer"; //textUserName.getText().toString();
                url = baseUrl + userName;

                url = url + "&pass=";
                password = "78MYzDuUcGYh"; //textPassword.getText().toString();
                url = url + password;

                Log.d("TextConnectionURL = ", url);

                JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {

                                Log.d("TestConnectionDelta", "connexion Volley OK");

                                try {

                                    result = response.getString("result");
                                    api = response.getString("api");
                                    token = response.getString("token");

                                    if(result.equals("OK")){
                                        Log.d("TestConnectionDelta","checkResult est true");
                                        Intent myIntent = new Intent(ConnectionActivity.this, MyJuryActivity.class);
                                        myIntent.putExtra("user_name",userName);
                                        myIntent.putExtra("token",token);
                                        startActivity(myIntent);
                                    } else {
                                        Log.e("TestConnectionDelta","checkResult est FALSE");
                                    }

                                    Log.d("TestConnectionDelta", "Le token = " + token);

                                } catch (JSONException e) {
                                    Log.e("TestConnectionDelta","JSON a pas marché");
                                    e.printStackTrace();
                                }

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
                        assert inflater != null;
                        @SuppressLint("InflateParams") View customView = inflater.inflate(R.layout.popup_connection,null);

                        mPopupWindow = new PopupWindow(
                                customView,
                                RelativeLayout.LayoutParams.WRAP_CONTENT,
                                RelativeLayout.LayoutParams.WRAP_CONTENT
                        );

                        if(Build.VERSION.SDK_INT>=21){
                            mPopupWindow.setElevation(5.0f);
                        }

                        mPopupWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        mPopupWindow.setTouchInterceptor(new View.OnTouchListener() {
                            @SuppressLint("ClickableViewAccessibility")
                            public boolean onTouch(View v, MotionEvent event) {
                                if(event.getAction() == MotionEvent.ACTION_OUTSIDE) {
                                    mPopupWindow.dismiss();
                                    return true;
                                }
                                return false;
                            }
                        });
                        mPopupWindow.setOutsideTouchable(true);

                        mPopupWindow.showAtLocation(mLinearLayout, Gravity.TOP,0,360);

                        Log.e("TestConnectionDelta", "Connexion VolleyError");
                        error.printStackTrace();
                    }
                });
                mRequestQueue.add(request);
            }
        });
    }

    public void clickJuryCard(ProjectItem mProjectList) {
        Intent intent = new Intent(this, DetailsActivity.class);
        // TODO intent.putExtra(JURY_EXTRA, mProjectList);
        startActivity(intent);
    }
}
