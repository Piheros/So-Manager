package fr.eseo.dis.pavlovpi.somanager.data;

public class ProjectMemberItem {

    private String projectMemberName;

    public ProjectMemberItem(String projectMemberName) {
        this.projectMemberName = projectMemberName;
    }

    public String getProjectMemberName() {
        return projectMemberName;
    }
}
