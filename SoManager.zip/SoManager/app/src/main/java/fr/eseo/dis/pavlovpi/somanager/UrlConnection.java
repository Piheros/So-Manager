package fr.eseo.dis.pavlovpi.somanager;

import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

public class UrlConnection {
/*
    private String userName;
    private String password;

    private String result;
    private String api;
    private String token;

    private String url = "https://192.168.4.248/pfe/webservice.php?q=LOGON";


    public UrlConnection(String name, String pass, RequestQueue requestQueue){
        NukeSSL.nuke();

        connectionFirstUrl(name, pass, requestQueue);

    }


    public void connectionFirstUrl(String name, String pass, RequestQueue requestQueue){
        setUserName(name);
        setUserPassword(pass);

        this.url = this.url + "&user=" + this.getUserName() + "&pass=" + this.getUserPassword();

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        Log.d("SoManagerBaseUrlConnect", "connexion Volley OK");

                        try {

                            String result = response.getString("result");
                            String api = response.getString("api");
                            String token = response.getString("token");

                            setResult(result);
                            setApi(api);
                            setUserToken(token);

                        } catch (JSONException e) {
                            Log.e("SoManagerBaseUrlConnect","JSON a pas marché");
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("SoManagerBaseUrlConnect", "connexion VolleyError");
                error.printStackTrace();
            }
        });

        requestQueue.add(request);
    }

    private void setUserName(String name){
        this.userName =  name;
    }

    private void setUserPassword(String pass){
        this.password =  pass;
    }

    private void setResult(String result){
        this.result = result;
    }

    private void setApi(String api){
        this.api = api;
    }

    private void setUserToken(String token){
        this.token = token;
    }

    public String getUserName(){
        return this.userName;
    }

    public String getUserPassword(){
        return this.password;
    }

    public String getUserToken(){
        return this.token;
    }

    public String getResult(){
        return this.result;
    }

    public String getApi(){
        return this.api;
    }

    public String getUserUrl(){
        return this.url;
    }
*/
}
