package fr.eseo.dis.pavlovpi.somanager.data;

public class NotationItem {

    private String forename;
    private String note;
    private String surname;

    public NotationItem (String forename, String surname, String note) {
        this.forename = forename;
        this.surname = surname;
        this.note = note;
    }

    public String getNotationForename() {
        return this.forename;
    }

    public String getNotationSurname() {
        return this.surname;
    }

    public String getNotationNote() {
        return this.note;
    }

}
