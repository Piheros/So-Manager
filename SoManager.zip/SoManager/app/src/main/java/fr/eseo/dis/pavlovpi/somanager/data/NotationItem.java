package fr.eseo.dis.pavlovpi.somanager.data;

public class NotationItem {

    private String forename;
    private String note;
    private String noteAverage;
    private String surname;

    public NotationItem (String forename, String surname, String note,String noteAverage) {
        this.forename = forename;
        this.surname = surname;
        this.note = note;
        this.noteAverage = noteAverage;
    }

    public String getNotationForename() {
        return this.forename;
    }

    public String getNotationSurname() {
        return this.surname;
    }

    public String getNotationNote() {
        return this.note;
    }

    public String getNoteAverage() {
        return this.noteAverage;
    }

}
