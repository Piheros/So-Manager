package fr.eseo.dis.pavlovpi.somanager.data.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import fr.eseo.dis.pavlovpi.somanager.NotationActivity;
import fr.eseo.dis.pavlovpi.somanager.R;
import fr.eseo.dis.pavlovpi.somanager.data.NotationItem;

public class NotationAdapter extends RecyclerView.Adapter<NotationAdapter.NotationViewHolder>{

    private NotationActivity activity;
    private ArrayList<NotationItem> mNotationList;

    public NotationAdapter(NotationActivity activity, ArrayList<NotationItem> notationList) {
        this.activity = activity;
        this.mNotationList = notationList;
    }

    @NonNull
    @Override
    public NotationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.notation_card_layout, parent, false);
        return new NotationViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull NotationViewHolder holder, int position) {
        final NotationItem currentItem = mNotationList.get(position);

        String notationForename = currentItem.getNotationForename();
        String notationSurname = currentItem.getNotationSurname();
        String notationNote = currentItem.getNotationNote();

        holder.mTextViewSurname.setText(notationSurname);
        holder.mTextViewForename.setText(notationForename);
        holder.mTextViewNote.setText(notationNote);
    }

    @Override
    public int getItemCount() {
        return this.mNotationList.size();
    }

    class NotationViewHolder extends RecyclerView.ViewHolder{

        private final View view;

        public TextView mTextViewSurname;
        public TextView mTextViewForename;
        public TextView mTextViewNote;

        public NotationViewHolder (View itemView) {
            super(itemView);
            this.view = itemView;
            mTextViewSurname = itemView.findViewById(R.id.notation_surename);
            mTextViewForename = itemView.findViewById(R.id.notation_forename);
            mTextViewNote = itemView.findViewById(R.id.tv_notation_note);
        }
    }

}
