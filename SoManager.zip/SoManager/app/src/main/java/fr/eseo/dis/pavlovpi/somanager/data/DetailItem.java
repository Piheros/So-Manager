package fr.eseo.dis.pavlovpi.somanager.data;

public class DetailItem {

    private String idProject;
    private String titleProject;
    private String descriptionProject;
    private String supervisor;

    public DetailItem(String idProject, String titleProject, String descriptionProject, String supervisor){
        this.idProject = idProject;
        this.titleProject = titleProject;
        this.descriptionProject = descriptionProject;
        this.supervisor = supervisor;
    }

    public String getIdProject() {
        return this.idProject;
    }

    public String getTitleProject() {
        return this.titleProject;
    }

    public String getDescriptionProject() {
        return this.descriptionProject;
    }

    public String getSupervisor(){
        return this.supervisor;
    }
}
