package fr.eseo.dis.pavlovpi.somanager.data;

public class JuryItem {

    private String idJury;
    private String date;
    private String info;
    private String supervisorName;

    public JuryItem(String idJury, String date, String info, String supervisorName){
        this.idJury = idJury;
        this.date = date;
        this.info = info;
        this.supervisorName = supervisorName;
    }

    public String getIdJury(){
        return this.idJury;
    }

    public String getDate(){
        return this.date;
    }

    public String getInfo(){
        return this.info;
    }

    public String getSupervisorName() {
        return this.supervisorName;
    }

}
