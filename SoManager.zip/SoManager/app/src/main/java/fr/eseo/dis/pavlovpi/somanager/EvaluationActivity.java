package fr.eseo.dis.pavlovpi.somanager;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class EvaluationActivity extends AppCompatActivity {

    private static final String TAG = EvaluationActivity.class.getSimpleName();

    //https://192.168.4.248/pfe/webservice.php?q=NEWNT&user=chavijer&proj=2&student=23&note=04token=

    private String pageType = "NEWNT";
    private String url = "https://192.168.4.248/pfe/webservice.php?q=" + pageType +"&user=";

    private String userName;
    private String token;
    private String projectId;
    private ArrayList<String> userIdList;

    private TextView myTextView;

    private RequestQueue mRequestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_evaluation);

        mRequestQueue = Volley.newRequestQueue(this);

        getValuesIntent();

        setListeners();

        myTextView = findViewById(R.id.evaluation_thingy);
        myTextView.setText(userIdList.get(0));
    }

    private void setJSONNote() {
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, this.url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d(TAG,"Succesfully set the note");
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "SoManager does not work");
                error.printStackTrace();
            }
        });

        mRequestQueue.add(request);
    }

    private void setListeners() {

        for(int i = 0; i < userIdList.size(); i++) {
            this.url = this.url + this.userName + "&proj=" + projectId + "&student=" + userIdList.get(i) + "&token=" + this.token;
            Log.d(TAG, "STUDENTIDNUMBER : " + userIdList.get(i));
            Log.d(TAG + " -- URL de MyJurys", "URL = " + this.url);
            //setJSONNote();
        }

    }

    private void getValuesIntent() {
        Intent i = getIntent();
        this.userIdList = i.getStringArrayListExtra("student_id_list");
        this.userName = i.getStringExtra("user_name");
        this.token = i.getStringExtra("token");
        this.projectId = i.getStringExtra("project_id");
    }

    private void createURLToSetNote(String studentId){
        this.url = this.url + this.userName + "&proj=" + projectId + "&student=" + studentId + "&note=" + "4" + "&token=" + this.token;
        Log.d(TAG + " -- URL de MyJurys", "URL = " + this.url);
    }

}
