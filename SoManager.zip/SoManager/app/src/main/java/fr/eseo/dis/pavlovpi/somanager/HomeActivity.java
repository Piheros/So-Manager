package fr.eseo.dis.pavlovpi.somanager;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class HomeActivity extends AppCompatActivity {

    private Button btnVisitor;
    private Button btnTestConnection;

    private String userToken;
    private static final String URLJPO = "https://192.168.4.248/pfe/webservice.php?q=LOGON&user=jpo&pass=Lsm5hs51s9ks";


    private RequestQueue mRequestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        NukeSSL.nuke();

        btnVisitor = findViewById(R.id.button_visitor);
        btnTestConnection = findViewById(R.id.button_connection);

        mRequestQueue = Volley.newRequestQueue(this);

        btnVisitor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, URLJPO, null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                try {
                                    Log.d("SoManagerActivityBeta", "JSON receive");
                                    Log.d("SoManagerActivityBeta","JSON result = " + response.getString("result"));
                                    userToken = response.getString("token");
                                    Log.d("SoManagerActivityBeta","LE TOKEN HOME = " + userToken);

                                    Intent myIntent = new Intent(HomeActivity.this, ProjectsActivity.class);
                                    myIntent.putExtra("user_name","jpo");
                                    myIntent.putExtra("token",userToken);
                                    startActivity(myIntent);

                                } catch (JSONException e) {
                                    Log.e("SoManagerActivityBeta","JSON does not work");
                                    e.printStackTrace();
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("SoManagerActivityBeta", "SoManager does not work");
                        error.printStackTrace();
                    }
                });

                mRequestQueue.add(request);
            }
        });

        btnTestConnection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(HomeActivity.this, ConnectionActivity.class);
                startActivity(myIntent);
            }
        });

        btnVisitor.setVisibility(View.VISIBLE);
        btnTestConnection.setVisibility(View.VISIBLE);
    }

}
