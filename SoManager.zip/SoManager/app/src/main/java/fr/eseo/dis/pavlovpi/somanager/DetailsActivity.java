package fr.eseo.dis.pavlovpi.somanager;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import fr.eseo.dis.pavlovpi.somanager.data.ProjectMemberItem;
import fr.eseo.dis.pavlovpi.somanager.data.adapters.ProjectMemberAdapter;


public class DetailsActivity extends AppCompatActivity{

    private static final String TAG = DetailsActivity.class.getSimpleName();

    //https://192.168.4.248/pfe/webservice.php?q=POSTR&user=chavijer&proj=2&style=THUMB&token=

    private String pageType = "POSTR";
    private String url = "https://192.168.4.248/pfe/webservice.php?q=" + pageType +"&user=";

    private String userName;
    private String token;

    private Button btnDetails;
    private Button btnCommentaire;
    private Button btnEvaluation;

    private TextView titre;
    private TextView supervisorNameTextView;
    private TextView projectDescriptionView;
    private ImageView mImageView;

    private String titleProject;
    private String supervisorName;
    private String studentsMembers;
    private String individualStudentName;
    private String projectDescription;
    private String projectId;
    private ArrayList<String> userIdList;

    private RecyclerView myRecyclerView;
    private ProjectMemberAdapter mProjectMemberAdapter;
    private ArrayList<ProjectMemberItem> mProjectMemberList;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        myRecyclerView = findViewById(R.id.project_member_name_view);
        myRecyclerView.setHasFixedSize(true);
        myRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mProjectMemberList = new ArrayList<>();

        userIdList = new ArrayList<>();

        getViews();
        getValuesIntent();

        createUrlToGetPosterThumb();
        parseJson();

        Picasso.with(DetailsActivity.this).load(this.url).placeholder( R.drawable.progress_animation ).into(mImageView);
        setListeners();
    }

    private void getViews() {
        btnDetails = findViewById(R.id.button_details);
        btnCommentaire = findViewById(R.id.button_commentaire);
        btnEvaluation = findViewById(R.id.button_evaluation);
        titre = findViewById(R.id.detail_project_title);
        supervisorNameTextView = findViewById(R.id.detail_project_supervisor_name);
        projectDescriptionView = findViewById(R.id.jury_project_description_view);
        mImageView = findViewById(R.id.poster_project_view);
    }

    private void getValuesIntent() {
        Intent i = getIntent();
        userName = i.getStringExtra("user_name");
        token = i.getStringExtra("token");
        titleProject = i.getStringExtra("project_title");
        supervisorName = i.getStringExtra("supervisor_name");
        studentsMembers = i.getStringExtra("students_member");
        projectDescription = i.getStringExtra("project_description");
        projectId = i.getStringExtra("project_id");
    }

    private void parseJson() {
        try {
            JSONObject studentsJsonObject = new JSONObject(studentsMembers);
            JSONArray studentsJsonArray = studentsJsonObject.getJSONArray("students");

            for (int j = 0; j < studentsJsonArray.length(); j++) {
                JSONObject studentsArrayObject = studentsJsonArray.getJSONObject(j);

                String studentForename = studentsArrayObject.getString("forename");
                String studentSurname = studentsArrayObject.getString("surname");
                String userId = studentsArrayObject.getString("userId");

                this.userIdList.add(userId);

                individualStudentName = studentForename + " " + studentSurname;

                mProjectMemberList.add(new ProjectMemberItem(individualStudentName));
            }

            mProjectMemberAdapter = new ProjectMemberAdapter(DetailsActivity.this, mProjectMemberList);
            myRecyclerView.setAdapter(mProjectMemberAdapter);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        titre.setText(titleProject);
        supervisorNameTextView.setText("Superviseur : " + supervisorName);
        projectDescriptionView.setText(projectDescription);
    }

    private void createUrlToGetPosterThumb(){
        this.url = this.url + this.userName + "&proj=" + projectId + "&style=FULL" + "&token=" + this.token;
        Log.d(TAG + " -- URL de ProjectThumb", "URL = " + this.url);
    }

    private void setListeners() {
        btnDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailsActivity.this, NotationActivity.class);
                intent.putExtra("user_name", userName);
                intent.putExtra("token", token);
                intent.putExtra("project_id",projectId);
                startActivity(intent);
            }
        });

        btnCommentaire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailsActivity.this, CommentaireActivity.class);
                startActivity(intent);
            }
        });

        btnEvaluation.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(DetailsActivity.this, EvaluationActivity.class);
                        intent.putExtra("user_name", userName);
                        intent.putExtra("token", token);
                        intent.putExtra("project_id",projectId);
                        intent.putStringArrayListExtra("student_id_list", userIdList);
                        startActivity(intent);
                    }
        });

        btnCommentaire.setVisibility(View.VISIBLE);
    }

}
