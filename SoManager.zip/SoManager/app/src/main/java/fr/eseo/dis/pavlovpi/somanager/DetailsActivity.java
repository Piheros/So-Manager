package fr.eseo.dis.pavlovpi.somanager;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import fr.eseo.dis.pavlovpi.somanager.data.DetailItem;
import fr.eseo.dis.pavlovpi.somanager.data.JuryItem;
import fr.eseo.dis.pavlovpi.somanager.data.ProjectItem;


public class DetailsActivity extends AppCompatActivity{

    private Button btnDetails;
    private Button btnEvaluation;

    private TextView titre;
    private TextView supervisorNameTextView;

    private String titleProject;
    private String supervisorName;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        btnDetails = findViewById(R.id.button_details);
        titre = findViewById(R.id.detail_project_title);
        supervisorNameTextView = findViewById(R.id.detail_project_supervisor_name);

        Intent i = getIntent();
        titleProject = i.getStringExtra("project_title");
        supervisorName = i.getStringExtra("supervisor_name");
        titre.setText(titleProject);
        supervisorNameTextView.setText(supervisorName);

        btnDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailsActivity.this, NotationActivity.class);
                //intent.putExtra(SoManagerActivity.FILM_EXTRA, film);
                startActivity(intent);
            }
        });
    }



}
