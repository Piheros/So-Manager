package fr.eseo.dis.pavlovpi.somanager;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import fr.eseo.dis.pavlovpi.somanager.data.DetailItem;
import fr.eseo.dis.pavlovpi.somanager.data.JuryItem;
import fr.eseo.dis.pavlovpi.somanager.data.ProjectItem;
import fr.eseo.dis.pavlovpi.somanager.data.ProjectMemberItem;
import fr.eseo.dis.pavlovpi.somanager.data.adapters.ProjectMemberAdapter;


public class DetailsActivity extends AppCompatActivity{

    private static final String TAG = DetailsActivity.class.getSimpleName();

    private Button btnDetails;
    private Button btnEvaluation;

    private TextView titre;
    private TextView supervisorNameTextView;
    private TextView projectDescriptionView;

    private String titleProject;
    private String supervisorName;
    private String studentsMembers;
    private String individualStudentName;
    private String projectDescription;
    private String projectId;

    private RecyclerView myRecyclerView;
    private ProjectMemberAdapter mProjectMemberAdapter;
    private ArrayList<ProjectMemberItem> mProjectMemberList;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        myRecyclerView = findViewById(R.id.project_member_name_view);
        myRecyclerView.setHasFixedSize(true);
        myRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mProjectMemberList = new ArrayList<>();

        btnDetails = findViewById(R.id.button_details);
        titre = findViewById(R.id.detail_project_title);
        supervisorNameTextView = findViewById(R.id.detail_project_supervisor_name);
        projectDescriptionView = findViewById(R.id.jury_project_description_view);

        Intent i = getIntent();
        titleProject = i.getStringExtra("project_title");
        supervisorName = i.getStringExtra("supervisor_name");
        studentsMembers = i.getStringExtra("students_member");
        projectDescription = i.getStringExtra("project_description");
        projectId = i.getStringExtra("project_id");

        try {
            JSONObject studentsJsonObject = new JSONObject(studentsMembers);
            JSONArray studentsJsonArray = studentsJsonObject.getJSONArray("students");

            for (int j = 0; j < studentsJsonArray.length(); j++) {
                JSONObject studentsArrayObject = studentsJsonArray.getJSONObject(j);

                String studentForename = studentsArrayObject.getString("forename");
                String studentSurname = studentsArrayObject.getString("surname");

                individualStudentName = studentForename + " " + studentSurname;

                mProjectMemberList.add(new ProjectMemberItem(individualStudentName));
            }

            mProjectMemberAdapter = new ProjectMemberAdapter(DetailsActivity.this, mProjectMemberList);
            myRecyclerView.setAdapter(mProjectMemberAdapter);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        titre.setText(titleProject);
        supervisorNameTextView.setText(supervisorName);
        projectDescriptionView.setText(projectDescription);

        btnDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailsActivity.this, NotationActivity.class);
                //intent.putExtra(SoManagerActivity.FILM_EXTRA, film);
                startActivity(intent);
            }
        });
    }



}
