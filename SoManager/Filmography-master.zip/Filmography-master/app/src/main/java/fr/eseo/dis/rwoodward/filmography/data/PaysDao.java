package fr.eseo.dis.rwoodward.filmography.data;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Query;

import java.util.List;

@Dao
public interface PaysDao {

    @Query("SELECT * FROM pays")
    public List<Pays> findAllPays();

    @Query("SELECT * FROM pays WHERE code = :code")
    public Pays findPaysFromCode(String code);
}
