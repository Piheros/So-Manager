package fr.eseo.dis.rwoodward.filmography;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import fr.eseo.dis.rwoodward.filmography.data.Film;
import fr.eseo.dis.rwoodward.filmography.data.FilmographyDatabase;
import fr.eseo.dis.rwoodward.filmography.data.Internaute;
import fr.eseo.dis.rwoodward.filmography.data.Notation;
import fr.eseo.dis.rwoodward.filmography.data.NotationAvecInternaute;
import fr.eseo.dis.rwoodward.filmography.data.adapters.FilmNotationAdapter;
import fr.eseo.dis.rwoodward.filmography.data.source.DummyData;

public class FilmNotationActivity extends AppCompatActivity {

    private FilmNotationAdapter filmNotationAdapter;
    private int idFilm;
    private Film film;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_film_notation);
        Intent intent = getIntent();
        Bundle data = intent.getExtras();
        film = (Film) data.getParcelable(FilmographyActivity.FILM_EXTRA);
        idFilm = film.getIdFilm();
        RecyclerView recycler = findViewById(R.id.notationList);
        recycler.setHasFixedSize(true);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        recycler.setLayoutManager(llm);
        filmNotationAdapter = new FilmNotationAdapter(this);
        recycler.setAdapter(filmNotationAdapter);
        loadNotationDetails();
    }

    /*
    private void loadNotationDetails(){
        List<NotationAvecInternaute> noteInter = new ArrayList<>();
        for(Notation notation : DummyData.getNotations()){
            if(notation.getIdFilm() == idFilm){
                int indice =0;
                Internaute internaute = null;
                while(indice < DummyData.getInternaute().size() && internaute == null){
                    if(DummyData.getInternaute().get(indice).getEmail().equals(notation.getEmail())){
                        internaute = DummyData.getInternaute().get(indice);
                        noteInter.add(new NotationAvecInternaute(notation,internaute));
                    }
                    else{
                        indice++;
                    }
                }
            }
        }
        filmNotationAdapter.setNotations(noteInter);
    }
    */

    private void loadNotationDetails(){
        filmNotationAdapter.setNotations(FilmographyDatabase.getDatabase(this).notationDao().findNotationsWithInternautesForFilm(idFilm));
        filmNotationAdapter.notifyDataSetChanged();
    }

}
