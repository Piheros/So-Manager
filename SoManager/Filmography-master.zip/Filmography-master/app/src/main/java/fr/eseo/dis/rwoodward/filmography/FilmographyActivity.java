package fr.eseo.dis.rwoodward.filmography;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;


import fr.eseo.dis.rwoodward.filmography.data.Film;
import fr.eseo.dis.rwoodward.filmography.data.FilmographyDatabase;
import fr.eseo.dis.rwoodward.filmography.data.adapters.FilmographyAdapter;
import fr.eseo.dis.rwoodward.filmography.data.source.DummyData;

public class FilmographyActivity extends AppCompatActivity {

    public static final String FILM_EXTRA = "film_extra";
    public static int NEW_CARD_COUNTER;

    private FilmographyAdapter filmographyAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filmography);
        NEW_CARD_COUNTER = 0;
        RecyclerView recycler = (RecyclerView)findViewById(R.id.filmographyList);
        recycler.setHasFixedSize(true);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        recycler.setLayoutManager(llm);
        filmographyAdapter = new FilmographyAdapter(this);
        recycler.setAdapter(filmographyAdapter);
        loadAllFilmsData();
    }

/*
    private void loadAllFilmsData(){
        filmographyAdapter.setFilms(DummyData.getFilms());
    }
*/
    public void clickFilmCard(Film film) {
        Intent intent = new Intent(this, FilmDetailsActivity.class);
        intent.putExtra(FILM_EXTRA, film);
        startActivity(intent);
    }


    private void loadAllFilmsData(){
        filmographyAdapter.setFilms(FilmographyDatabase.getDatabase(this).filmDao().findAllFilms());
        filmographyAdapter.notifyDataSetChanged();
    }

}
