package fr.eseo.dis.rwoodward.filmography.data;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

@Entity(tableName = "pays")
public class Pays {

    @PrimaryKey
    @NonNull
    public String code;

    @NonNull
    public String nom;

    @NonNull
    public String langue;

    public Pays(String code, String nom, String langue) {
        this.code = code;
        this.nom = nom;
        this.langue = langue;
    }

    @NonNull
    public String getCode() {
        return code;
    }

    public void setCode(@NonNull String code) {
        this.code = code;
    }

    @NonNull
    public String getNom() {
        return nom;
    }

    public void setNom(@NonNull String nom) {
        this.nom = nom;
    }

    @NonNull
    public String getLangue() {
        return langue;
    }

    public void setLangue(@NonNull String langue) {
        this.langue = langue;
    }
}
