package fr.eseo.dis.rwoodward.filmography.data.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import fr.eseo.dis.rwoodward.filmography.FilmographyActivity;
import fr.eseo.dis.rwoodward.filmography.R;
import fr.eseo.dis.rwoodward.filmography.data.Film;

public class FilmographyAdapter extends RecyclerView.Adapter<FilmographyAdapter.FilmographyViewHolder>{

    private FilmographyActivity activity;

    private List<Integer> positionsExpanded;

    private List<Film> films;

    public FilmographyAdapter(FilmographyActivity filmographyActivity){
        this.activity = filmographyActivity;
        setFilms(new ArrayList<Film>());
        positionsExpanded = new ArrayList<>();
    }

    public void setFilms(List<Film> films){
        this.films = films;
    }

    @Override
    public int getItemCount(){
        return films.size();
    }


    @Override
    public FilmographyViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View filmView = LayoutInflater.from(parent.getContext()).inflate(R.layout.filmography_card_layout, parent, false);
        CardView filmCardView = (CardView)filmView;
        filmCardView.setCardElevation(3 * FilmographyActivity.NEW_CARD_COUNTER++);
        return new FilmographyViewHolder(filmView);
    }


    @Override
    public void onBindViewHolder(@NonNull FilmographyViewHolder holder, final int position) {
        final Film film = films.get(position);
        holder.filmTitre.setText(film.getTitre());
        holder.filmGenre.setText(film.getGenre());
        holder.filmAnnee.setText(String.valueOf(film.getAnnee()));
        holder.filmResume.setText(film.getResume());

        holder.view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.clickFilmCard(film);
            }
        });
        if (positionsExpanded.contains(position)) {
            holder.filmResume.setVisibility(View.VISIBLE);
        } else {
            holder.filmResume.setVisibility(View.GONE);
        }

        holder.view.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                TextView resume = (TextView) v.findViewById(R.id.tv_film_resume);
                TextView resumeLabel = (TextView) v.findViewById(R.id.tv_film_resume_label);
                if (positionsExpanded.contains(position)) {
                    resume.setVisibility(View.GONE);
                    resumeLabel.setVisibility(View.GONE);
                    positionsExpanded.remove(new Integer(position));
                } else {
                    resume.setVisibility(View.VISIBLE);
                    resumeLabel.setVisibility(View.VISIBLE);
                    positionsExpanded.add(position);
                }
                return true;
            }
        });
    }


    class FilmographyViewHolder extends RecyclerView.ViewHolder{

        private final View view;

        private final TextView filmTitre;
        private final TextView filmGenre;
        private final TextView filmAnnee;
        private final TextView filmResume;

        public FilmographyViewHolder(View view){
            super(view);
            this.view = view;
            filmTitre = view.findViewById(R.id.tv_film_title);
            filmGenre = view.findViewById(R.id.tv_film_genre);
            filmAnnee = view.findViewById(R.id.tv_film_annee);
            filmResume = view.findViewById(R.id.tv_film_resume);



        }
    }
}
